public class SimpleCounter {
        
    private static int count = 0;
    public static void increment() {
        count++;
    }
    public int getCount(){
        return count;
    }
}   